﻿using System;

// Interface
interface IPayroll
{
    void CalculateSalary();
}

// Base Class
class Employee
{
    protected int empId;
    protected string empName;

    public Employee(int id, string name)
    {
        empId = id;
        empName = name;
    }

    public virtual void DisplayDetails()
    {
        Console.WriteLine("Employee ID   : " + empId);
        Console.WriteLine("Employee Name : " + empName);
    }
}

// Derived Class
class PermanentEmployee : Employee, IPayroll
{
    private double basicSalary;
    private double hra;
    private double da;
    private double totalSalary;

    public PermanentEmployee(int id, string name, double basic)
        : base(id, name)
    {
        basicSalary = basic;
    }

    // Interface Method
    public void CalculateSalary()
    {
        hra = basicSalary * 0.20;   // 20% HRA
        da = basicSalary * 0.10;    // 10% DA
        totalSalary = basicSalary + hra + da;
    }

    // Polymorphism (Method Overriding)
    public override void DisplayDetails()
    {
        base.DisplayDetails();
        Console.WriteLine("Basic Salary  : " + basicSalary);
        Console.WriteLine("HRA           : " + hra);
        Console.WriteLine("DA            : " + da);
        Console.WriteLine("Total Salary  : " + totalSalary);
    }
}

// Main Class
class Program
{
    static void Main(string[] args)
    {
        // Polymorphism
        Employee emp = new PermanentEmployee(101, "Rahul Kumar", 50000);

        // Interface Reference
        IPayroll payroll = (IPayroll)emp;
        payroll.CalculateSalary();

        emp.DisplayDetails();

        Console.ReadKey();
    }
}
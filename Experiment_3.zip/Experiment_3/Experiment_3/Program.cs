﻿using System;

class ExpenseTracker
{
    static void Main()
    {
        string expenseName;
        decimal amount;
        int expenseId;
        string expenseDetails;
        string expenseFoodData;


        Console.Write("======Simple Expense Tracker======= \n");
        try
        {
            Console.Write("Enter Expense Id: ");
            expenseId = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Expense Name: ");
            expenseName = Console.ReadLine();

            Console.Write("Enter Expense Amount: ");
            amount = Convert.ToDecimal(Console.ReadLine());

            Console.Write("Enter Expense Details: ");
            expenseDetails = Console.ReadLine();

            Console.Write("Enter Expense Food Data: ");
            expenseFoodData = Console.ReadLine();

            // Manually throw exception
            if (amount <= 0)
            {
                throw new Exception("Expense amount must be greater than 0.");
            }

            Console.WriteLine("\n===== Expense Added Successfully =====");
            Console.WriteLine("Expense Id      : " + expenseId);
            Console.WriteLine("Expense Name    : " + expenseName);
            Console.WriteLine("Expense Amount  : ₹" + amount);
            Console.WriteLine("Expense Details : " + expenseDetails);
            Console.WriteLine("Expense Food    : " + expenseFoodData);
        }
        catch (FormatException)
        {
            Console.WriteLine("Error: Please enter valid numeric values for Expense Id and Amount.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
        }
        finally
        {
            Console.WriteLine("\nThank you for using the Expense Tracker.");
        }

        Console.ReadKey();
    }
}
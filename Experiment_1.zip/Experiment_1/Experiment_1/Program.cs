﻿//using System;

//namespace StudentAdmissionManagement
//{
//    // Class
//    class Student
//    {
//        // Private data members (Access Modifier)
//        private int studentId;
//        private string studentName;
//        private string course;
//        private double admissionFee;

//        // Default Constructor
//        public Student()
//        {
//            studentId = 0;
//            studentName = "Not Assigned";
//            course = "Not Assigned";
//            admissionFee = 0;
//        }

//        // Parameterized Constructor
//        public Student(int id, string name, string course, double fee)
//        {
//            studentId = id;
//            studentName = name;
//            this.course = course;
//            admissionFee = fee;
//        }

//        // Public Method to Display Student Details
//        public void DisplayDetails()
//        {
//            Console.WriteLine("Student ID      : " + studentId);
//            Console.WriteLine("Student Name    : " + studentName);
//            Console.WriteLine("Course          : " + course);
//            Console.WriteLine("Admission Fee   : " + admissionFee);
//        }

//        // Public Method to Update Details
//        public void UpdateDetails(string name, string course, double fee)
//        {
//            studentName = name;
//            this.course = course;
//            admissionFee = fee;
//        }
//    }

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            // Creating Objects
//            Student student1 = new Student();
//            Student student2 = new Student(101, "Rahul Kumar", "B.Tech Computer Engineering", 50000);

//            Console.WriteLine("Default Constructor Output:");
//            student1.DisplayDetails();

//            Console.WriteLine("\nParameterized Constructor Output:");
//            student2.DisplayDetails();

//            // Updating student1 details
//            student1.UpdateDetails("Anjali Sharma", "BCA", 40000);

//            Console.WriteLine("\nUpdated Student Details:");
//            student1.DisplayDetails();

//            Console.ReadKey();
//        }
//    }
//}
using System;

namespace StudentAdmissionManagement
{
    class Student
    {
        // Private Data Members (Access Modifiers)
        private int studentId;
        private string studentName;
        private string course;
        private double fees;

        // Constructor
        public Student(int id, string name, string courseName, double fee)
        {
            studentId = id;
            studentName = name;
            course = courseName;
            fees = fee;
        }

        // Public Method to Display Student Details
        public void DisplayDetails()
        {
            Console.WriteLine("\n----- Student Admission Details -----");
            Console.WriteLine("Student ID   : " + studentId);
            Console.WriteLine("Student Name : " + studentName);
            Console.WriteLine("Course       : " + course);
            Console.WriteLine("Fees         : " + fees);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            int id;
            string name, course;
            double fee;

            Console.Write("Enter Student ID: ");
            id = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Student Name: ");
            name = Console.ReadLine();

            Console.Write("Enter Course Name: ");
            course = Console.ReadLine();

            Console.Write("Enter Course Fees: ");
            fee = Convert.ToDouble(Console.ReadLine());

            // Creating Object
            Student s1 = new Student(id, name, course, fee);

            // Calling Method
            s1.DisplayDetails();

            Console.ReadKey();
        }
    }
}